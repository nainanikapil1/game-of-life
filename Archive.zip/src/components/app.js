import React, { Component } from 'react';
import Board from '../containers/board';
import Control from '../containers/control';
import { Row } from 'antd';
export default () => (
  <Row>
    <Board />
    <Control />
  </Row>
)
